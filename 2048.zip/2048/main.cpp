#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include "res.h"//��Դ�ļ� 
using namespace std;
const char* WINDOW_TITLE = "��ƴͼ��"; // ���� 
const char* WINDOW_CLASS_NAME = WINDOW_TITLE; // ���� 
HINSTANCE inst;
HWND hwnd;
HDC hdc = NULL;//ȫ���豸�������
HDC mdc = NULL;//ȫ���ڴ�DC���
HDC bufdc = NULL;//ȫ���ڴ�DC��� ��Ϊ������ 
HBITMAP bmp = NULL;
HBITMAP	bmp_victory = NULL;
int data[16] = {0};
int nowScore=0, maxScore=0;
bool gameOver = 0;
const int times = 1;//�������㱶�ˣ�����debug
const int MARGIN = 30;
const int WINDOW_WIDTH = 550, WINDOW_HEIGHT = 680;
void redraw()
{
	RedrawWindow(::hwnd, NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);
}

void DrawLine(HDC &hdc, int x, int y, int x1, int y1)
{
	MoveToEx(hdc, x, y, NULL);
	LineTo(hdc, x1, y1);
}

void DrawRectangle(HDC &hdc, int x, int y, int x1, int y1)
{
	DrawLine(hdc, x, y, x1, y);
	DrawLine(hdc, x1, y, x1, y1);
	DrawLine(hdc, x1, y1, x, y1);
	DrawLine(hdc, x, y1, x, y);
}

void DrawFill(HDC &hdc, int x, int y, int width, int height)
{
	int x1 = x+width, y1 = y + height;
	Rectangle(hdc, x, y, x1, y1);
}

void DrawBlock(HDC &hdc, int x, int y, COLORREF rgb)
{
	HBRUSH brush = CreateSolidBrush(rgb);
	HGDIOBJ obj = SelectObject(hdc, brush);
	DrawFill(hdc, MARGIN+115*x+15, 125 + 115*y+15, 100, 100);
	SelectObject(hdc, obj);
}

HFONT getFont(int width, int height, int weight)
{
	LOGFONT font;
	memset(&font,0,sizeof(LOGFONT));
	font.lfCharSet = GB2312_CHARSET;//������������
	font.lfWidth = width;//�������
	font.lfHeight = height;//����߶�
	font.lfWeight = weight; //����Ӵ�
	return CreateFontIndirect(&font);
}

void DrawItemText(HDC &hdc, int x, int y, const char* num, COLORREF rgb)
{
	SelectObject(hdc,getFont(20, 100, 90));
	SetTextColor(hdc,rgb);//����������ɫ
	RECT rect = {MARGIN+115*x+15, 125+115*y+15, MARGIN+115*x+15+100, 125+115*y+15+100};
	DrawText(hdc, num, strlen(num), &rect, DT_VCENTER|DT_CENTER);
//	TextOut(hdc, MARGIN+115*x+15, 125 + 115*y+15, num, strlen(num));
}

COLORREF getNumberBackgroundColor(int x)
{
	int r, g, b;
	switch (data[x])
	{
		case 2: {
			r=0xee, g=0xe4, b=0xda;
			break;
		}
		case 4: {
			r=0xed, g=0xe0, b=0xc8;
			break;
		}
		case 8: {
			r=0xf2, g=0x61, b=0x79;
			break;
		}
		case 16: {
			r=0xf5, g=0x95, b=0x63;
			break;
		}
		case 32: {
			r=0xf6, g=0x7c, b=0x5f;
			break;
		}
		case 64: {
			r=0xf6, g=0x5e, b=0x36;
			break;
		}
		case 128: {
			r=0xed, g=0xcf, b=0x72;
			break;
		}
		case 256: {
			r=0xed, g=0xcc, b=0x61;
			break;
		}
		case 512: {
			r=0x99, g=0xcc, b=0x00;
			break;
		}
		case 1024: {
			r=0x33, g=0x65, b=0xa5;
			break;
		}
		case 2048: {
			r=0x00, g=0x99, b=0xcc;
			break;
		}
		case 4096: {
			r=239, g=102, b=108;
			break;
		}
		case 8192: {
			r=236, g=77, b=87;
			break;
		}
		case 16384: {
			r=244, g=65, b=64;
			break;
		}
		case 32768: {
			r=112, g=179, b=210;
			break;
		}
		case 65536: {
			r=96, g=159, b=223;
			break;
		}
		case 131072: {
			r=24, g=130, b=205;
			break;
		}
		default: {
			r=0, g=0, b=255;
			break;
		}
	}
	return RGB(r,g,b);
}

COLORREF getNumberColor(int x)
{
	if (data[x] <= 4) return RGB(119, 110, 101);
	return RGB(255, 255, 255);
}

void drawWindow(HDC &hdc)
{
	COLORREF deep = RGB(1711, 171, 171), gray = RGB(211, 211, 211);
	HPEN pen = CreatePen(PS_SOLID, 10, deep);
	HBRUSH brush = CreateSolidBrush(deep);
	char ch[5];
	SelectObject(hdc, pen);
	SelectObject(hdc, brush);
	DrawFill(hdc, 190, MARGIN, 100, 65);//�÷ֿ� 
//	DrawFill(hdc, MARGIN, MARGIN, 100, 65);
//	DrawFill(hdc, WINDOW_WIDTH - 10 - MARGIN - 100, MARGIN, 100, 65);
//	DrawFill(hdc, WINDOW_WIDTH - 10 - MARGIN - MARGIN - 200, MARGIN, 100, 65);
	DrawFill(hdc, MARGIN, 125, 470, 470);//���ֽ���� 
	for (int i=0; i<4; i++)
	{
		for (int j=0; j<4; j++)
		{
			if (data[i*4+j] == 0)
			{
				DrawBlock(hdc, j, i, gray);
				continue;
			}
			DrawBlock(hdc, j, i, getNumberBackgroundColor(i*4+j));//����С�� 
			ch[0]=ch[1]=ch[2]=ch[3]=ch[4]=0;
			sprintf(ch, "%d", data[i*4+j]);
			DrawItemText(hdc, j, i, ch, getNumberColor(i*4+j));
		}
	}
	SetTextColor(hdc, RGB(255, 255, 255));
	SelectObject(hdc, getFont(0, 20, 0));
	TextOut(hdc, 220, 30, "�÷�", 4);
	SelectObject(hdc,getFont(0, 30, 90));
	ch[0]=ch[1]=ch[2]=ch[3]=ch[4]=0;
	sprintf(ch, "%d", nowScore);
	RECT rect = {190, MARGIN+30, 190+100, MARGIN+65};
	DrawText(hdc, ch, strlen(ch), &rect, DT_CENTER|DT_VCENTER);
//	TextOut(hdc, 210, 60, ch, strlen(ch));
}

int random()
{
	int x=0;
	do {
		x=rand()%16;
	} while(data[x] != 0);
	return x;
}

bool checkWin()
{
	bool zero=0, win=0;
	for (int i=0; i<4; i++)
	{
		for (int j=0; j<4; j++)
		{
//			if (data[i*4+j] == 2048)
//			{
//				MessageBox(::hwnd, "��Ӯ��", "tips", 0);
//				win = 1;
//				break;
//			}
			if (data[i*4+j] == 0)
			{
				zero = 1;
				break;
			}
		}
		if (win || zero) break;
	}
	if (zero==0)
	{
		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if ((j<3 && data[i*4+j] == data[i*4+j+1]) || (i<3 && data[i*4+j] == data[(i+1)*4+j]))
				{
					zero = 1;
					break;
				}
			}
			if (zero) break;
		}
		//zero = !zero;
	}
	if (zero == 0) MessageBox(::hwnd, "������", "tips", 0);
	if (win || zero==0)
	{
		gameOver = 1;
		return 0;
	}
	return 1;
}

void init()
{
	srand(time(0));
	memset(data, 0, sizeof(data));
	hdc = GetDC(hwnd);
	SetBkMode(hdc, TRANSPARENT);
	nowScore = 0;
	data[rand()%16]=2;
	gameOver = 0;
//	for (int i=0; i<16; i++)
//	{
//		int x=rand()%13;
//		data[i] = (1<<x);
//		if (x == 0) data[i]=0;
//	}
}

const int Delay = 200;
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		case WM_KEYDOWN: {
			if (gameOver) break;
			switch (wParam) {
				case 'A': 
				case VK_LEFT: {
					bool f=0;
					for (int i=0; i<4; i++)
					{
						for (int j=1; j<4; j++)
						{
							if (data[i*4+j] != 0)
							if (j-1 >= 0 && data[i*4+(j-1)]==0)
							{
								if (j-2 >= 0 && data[i*4+(j-2)]==0)
								{
									if (j-3 >= 0 && data[i*4+(j-3)]==0)
									{
										swap(data[i*4+j], data[i*4+(j-3)]);
										f=1;
									}
									else
									{
										swap(data[i*4+j], data[i*4+(j-2)]);
										f=1;
									}
									if (j-3>=0 && data[i*4+(j-3)]==data[i*4+(j-2)]) data[i*4+(j-3)]+=data[i*4+(j-2)], nowScore += data[i*4+(j-2)]*times, data[i*4+(j-2)]=0, f=1;
								}
								else
								{
									swap(data[i*4+j], data[i*4+(j-1)]);
									f=1;
								}
								if (j-2>=0 && data[i*4+(j-2)]==data[i*4+(j-1)]) data[i*4+(j-2)]+=data[i*4+(j-1)], nowScore += data[i*4+(j-1)]*times, data[i*4+(j-1)]=0, f=1;
							}
							else
							{
								if (j-1>=0 && data[i*4+(j-1)]==data[i*4+j]) data[i*4+(j-1)]+=data[i*4+j], nowScore += data[i*4+j]*times, data[i*4+j]=0, f=1;
							}
						}
					}
					
					if (f)
					{
						redraw();
						
						Sleep(Delay);
						data[random()]=1<<(rand()%2+1);
						redraw();
					}
					else if (!checkWin()) break;
					break;
				}
				case 'D':
				case VK_RIGHT: {
					bool f=0;
					for (int i=0; i<4; i++)
					{
						for (int j=2; j>=0; j--)
						{
							if (data[i*4+j] != 0)
							if (j+1 < 4 && data[i*4+(j+1)]==0)
							{
								if (j+2 < 4 && data[i*4+(j+2)]==0)
								{
									if (j+3 < 4 && data[i*4+(j+3)]==0)
									{
										swap(data[i*4+j], data[i*4+(j+3)]);
										f=1;
									}
									else
									{
										swap(data[i*4+j], data[i*4+(j+2)]);
										
										f=1;
									}
									if (j+3<4 && data[i*4+(j+3)]==data[i*4+(j+2)]) data[i*4+(j+3)]+=data[i*4+(j+2)], nowScore += data[i*4+(j+2)]*times, data[i*4+(j+2)]=0, f=1;
								}
								else
								{
									swap(data[i*4+j], data[i*4+(j+1)]);
									
									f=1;
								}
								if (j+2<4 && data[i*4+(j+2)]==data[i*4+(j+1)]) data[i*4+(j+2)]+=data[i*4+(j+1)], nowScore += data[i*4+(j+1)]*times, data[i*4+(j+1)]=0, f=1;
							}
							else if (j+1<4 && data[i*4+(j+1)]==data[i*4+j]) data[i*4+(j+1)]+=data[i*4+j], nowScore += data[i*4+j]*times, data[i*4+j]=0, f=1;
						}
					}
					
					if (f)
					{
						redraw();
						
						Sleep(Delay);
						data[random()]=1<<(rand()%2+1);
						redraw();
					}
					else if (!checkWin()) break;
					break;
				}
				case 'W':
				case VK_UP: {
					bool f=0;
					for (int j=0; j<4; j++)
					{
						for (int i=1; i<4; i++)
						{
							if (data[i*4+j] != 0)
							if (i-1 >= 0 && data[(i-1)*4+j]==0)
							{
								if (i-2 >= 0 && data[(i-2)*4+j]==0)
								{
									if (i-3 >= 0 && data[(i-3)*4+j]==0)
									{
										swap(data[i*4+j], data[(i-3)*4+j]);
										f=1;
									}
									else
									{
										swap(data[i*4+j], data[(i-2)*4+j]);
										
										f=1;
									}
									if (i-3>=0 && data[(i-3)*4+j]==data[(i-2)*4+j]) data[(i-3)*4+j]+=data[(i-2)*4+j], nowScore += data[(i-2)*4+j]*times, data[(i-2)*4+j]=0, f=1;
								}
								else
								{
									swap(data[i*4+j], data[(i-1)*4+j]);
									
									f=1;
								}
								if (i-2>=0 && data[(i-2)*4+j]==data[(i-1)*4+j]) data[(i-2)*4+j]+=data[(i-1)*4+j], nowScore += data[(i-1)*4+j]*times, data[(i-1)*4+j]=0, f=1;
							}
							else if (i-1>=0 && data[(i-1)*4+j]==data[i*4+j]) data[(i-1)*4+j]+=data[i*4+j], nowScore += data[i*4+j]*times, data[i*4+j]=0, f=1;
						}
					}
					
					if (f)
					{
						redraw();
						
						Sleep(Delay);
						data[random()]=1<<(rand()%2+1);
						redraw();
					}
					else if (!checkWin()) break;
					break;
				}
				case 'S':
				case VK_DOWN: {
					bool f=0;
					for (int j=0; j<4; j++)
					{
						for (int i=2; i>=0; i--)
						{
							if (data[i*4+j] != 0)
							if (i+1 < 4 && data[(i+1)*4+j]==0)
							{
								if (i+2 < 4 && data[(i+2)*4+j]==0)
								{
									if (i+3 < 4 && data[(i+3)*4+j]==0)
									{
										swap(data[i*4+j], data[(i+3)*4+j]);
										f=1;
									}
									else
									{
										swap(data[i*4+j], data[(i+2)*4+j]);
										
										f=1;
									}
									if (i+3<4 && data[(i+3)*4+j]==data[(i+2)*4+j]) data[(i+3)*4+j]+=data[(i+2)*4+j], nowScore += data[(i+2)*4+j]*times, data[(i+2)*4+j]=0, f=1;
								}
								else
								{
									swap(data[i*4+j], data[(i+1)*4+j]);
									
									f=1;
								}
								if (i+2<4 && data[(i+2)*4+j]==data[(i+1)*4+j]) data[(i+2)*4+j]+=data[(i+1)*4+j], nowScore += data[(i+1)*4+j]*times, data[(i+1)*4+j]=0, f=1;
							}
							else if (i+1<4 && data[(i+1)*4+j]==data[i*4+j]) data[(i+1)*4+j]+=data[i*4+j], nowScore += data[i*4+j]*times, data[i*4+j]=0, f=1;
						}
					}
					
					if (f)
					{
						redraw();
						
						Sleep(Delay);
						data[random()]=1<<(rand()%2+1);
						redraw();
					}
					else if (!checkWin()) break;
					break;
				}
			}
			break;
		}
		case WM_COMMAND: {
			switch (LOWORD(wParam))//�õ�id 
			{
				case ID_NEW_GAME://��� ����Ϸ 
				{
					init();
					redraw();
					break;
				}
				case ID_EXIT://�˳� 
				{
					PostQuitMessage(0);
					break;
				}
				case ID_SHOW_HELP://���� 
				{
					MessageBox(hwnd, "���������һ�WASD���ƶ�����", "Help", 0);
					break;
				}
				case ID_ABOUT://���� 
				{
					MessageBox(hwnd, "Name: 2048\nCopyright: pengpeng\nAuthor: ����\nDate: 2021/12/07 14:19\nDescription: �ҵ�2048��Ϸ", "About", 0);
					break;
				}
				default:
				{
					return DefWindowProc(hwnd, Message, wParam, lParam);
					break;
				}
			}
			break;
		}
		case WM_PAINT: {
			PAINTSTRUCT ps;
//			printf("redraw !\n");
			BeginPaint(hwnd, &ps);//�ز����٣���ȻMessageBox�������̵�����ԭ��֪�� 
			drawWindow(hdc);
			EndPaint(hwnd, &ps);//�� BeginPaint ��� 
			break;
		}
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		case WM_SYSCOMMAND: {//ϵͳ��Ϣ������������� 
			if (wParam == SC_MAXIMIZE) ;//������󻯰�ť 
			else DefWindowProc(hwnd, Message, wParam, lParam);
			break;
		}
		case WM_NCRBUTTONDOWN://�ڷǹ����������Ҽ�
		case WM_NCLBUTTONDBLCLK: {//�ڷǹ�����˫���һ�
			break;
		}
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	WNDCLASSEX wc;
	MSG Msg;
	inst = hInstance;
	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc; /* insert window procedure function here */
	wc.hInstance	 = hInstance;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszClassName = WINDOW_CLASS_NAME;
	wc.hIcon		 = LoadIcon(NULL, IDI_APPLICATION); /* use "A" as icon name when you want to use the project icon */
	wc.hIconSm		 = LoadIcon(NULL, IDI_APPLICATION); /* as above */

	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,WINDOW_CLASS_NAME,WINDOW_TITLE,WS_VISIBLE|WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,WINDOW_WIDTH,WINDOW_HEIGHT,NULL,LoadMenu(hInstance, MAKEINTRESOURCE(IDR_MENU)),hInstance,NULL);
	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}
	init();
	while(GetMessage(&Msg, NULL, 0, 0) > 0) {
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}
	return Msg.wParam;
}
